package inclass;

public class Person {
	String name;
	int age; 
	Person friend;
}
