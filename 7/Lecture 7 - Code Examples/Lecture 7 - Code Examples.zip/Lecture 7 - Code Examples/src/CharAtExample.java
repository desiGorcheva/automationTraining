
public class CharAtExample {
	public static void main(String[] args) {
		String b = "nqkaf string";
		
		System.out.println(b.charAt(4));
		
		System.out.println(b.substring(2, 5));
		
		String c = "             dRduG string    ";
		System.out.println(c);
		
		String trimmed = c.trim();
		
		System.out.println(trimmed);
		
		System.out.println(trimmed.toLowerCase());
		
		System.out.println(trimmed.toUpperCase());

	}
}
