
public class StringExamples {
	public static void main(String[] args) {
		String a = "Welcome to the \"string\" \npresentation";
		
		System.out.println(a);
		
		int stringLength = a.length();
		
		System.out.println(stringLength);
	}

}
