
public class ToStringDemo {

	public static void main(String[] args) {
		Integer a = 334;
		
		String theText334 = a.toString();
		
		
		System.out.println(theText334 + 5);
	}

}
