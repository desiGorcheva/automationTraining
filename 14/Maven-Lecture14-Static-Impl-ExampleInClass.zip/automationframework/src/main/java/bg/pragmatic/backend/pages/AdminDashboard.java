package bg.pragmatic.backend.pages;

import bg.pragmatic.core.pages.BasePage;

public class AdminDashboard extends BasePage {

}
