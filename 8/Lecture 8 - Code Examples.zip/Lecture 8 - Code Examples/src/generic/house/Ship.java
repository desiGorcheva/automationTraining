package generic.house;

public class Ship {
	
	void driveShip(){
		
	}
}
