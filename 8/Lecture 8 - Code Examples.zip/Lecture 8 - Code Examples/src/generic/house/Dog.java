package generic.house;

public class Dog extends Animal {

}
