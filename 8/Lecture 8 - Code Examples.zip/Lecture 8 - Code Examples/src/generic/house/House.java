package generic.house;

public class House<T extends Animal, Y extends Animal> {
	private T myThing;
	private Y otherThing;
	
	public Y getOtherThing() {
		return otherThing;
	}
	 
	public void setOtherThing(Y otherThing) {
		this.otherThing = otherThing;
	}

	protected T getMyThing() {
		return myThing;
	}

	public void setMyThing(T myThing) {
		this.myThing = myThing;
	}
	
	

	
	
}
