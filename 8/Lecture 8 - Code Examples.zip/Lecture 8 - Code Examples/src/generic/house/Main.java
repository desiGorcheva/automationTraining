package generic.house;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		Dog sharo = new Dog();
		Dog karaman = new Dog();
		Fish ribok = new Fish();
		
		House<Dog, Fish> dogHouse = new House<>();
		
		dogHouse.setMyThing(sharo);
		dogHouse.setOtherThing(ribok);
		
		
		House<Fish, Dog> shipDogHouse = new House<>();
		
		Ship myShip = new Ship();
		shipDogHouse.setMyThing(ribok);
		shipDogHouse.setOtherThing(karaman);
		
		
		
		List<Dog> dogList = new ArrayList<>();
		List<Fish> fishList = new ArrayList<>();
		
		List anythingIntheList = new ArrayList<>();

	}
}
