package generic.house;

public class Animal {

}
