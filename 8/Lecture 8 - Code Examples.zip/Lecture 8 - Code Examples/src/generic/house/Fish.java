package generic.house;

public class Fish extends Animal {

}
