package com.pragmatic.lesson8.generics.playground;

public class ColorCartridge implements ICartridge {

	@Override
	public void getFillPercentage() {
		System.out.println("Color Cartridge: 54% full");
	}

}
