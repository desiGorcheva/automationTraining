package com.pragmatic.lesson8.generics.boxexample;

public class Animal {

}
