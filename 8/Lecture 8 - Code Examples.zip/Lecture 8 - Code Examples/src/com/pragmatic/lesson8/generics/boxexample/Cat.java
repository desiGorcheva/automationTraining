package com.pragmatic.lesson8.generics.boxexample;

public class Cat extends Animal {

	public void print(){
		System.out.println("mqu");
	}
}
