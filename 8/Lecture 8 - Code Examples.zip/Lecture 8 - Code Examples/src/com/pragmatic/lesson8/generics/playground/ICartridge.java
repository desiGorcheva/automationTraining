package com.pragmatic.lesson8.generics.playground;

public interface ICartridge {
	
	public void getFillPercentage();

}
