package com.pragmatic.lesson8.generics.boxexample;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Box<T extends Animal> {
	
	private T thing;
	
	public T getThing() {
		return thing;
	}

	public void setThing(T thing) {
		this.thing = thing;
	}

	
	public void doSomthing(int myInt) {
		
	}
	
	public int returnsInt(){
		return 1;
	}
	
	

	public static void main(String[] args) {
		
		Box<Cat> myCatBox = new Box<Cat>();
		myCatBox.setThing(new Cat());
		Cat cat = myCatBox.getThing();
		
		Box<Dog> myDogBox = new Box<Dog>();
		myDogBox.setThing(new Dog());
		Dog dog = myDogBox.getThing();
		
		
		//compilation error because it's not a subtype of the bounded type
		//Box<Integer> myIntBox = new Box<Integer>();
		
		List list = new ArrayList();
		list.add(1);
		list.add(new Dog());
		list.add(new Cat());

		
		Iterator iter = list.iterator();
		while(iter.hasNext()) {
			Object obj = iter.next();
			if(obj instanceof Cat) {
				((Cat)obj).print();
			}
		}
		
//		for(Object ob : list) {
//			
//		}
	
	}
	
}
