package com.pragmatic.lesson8.generics.boxexample;

public class Dog extends Animal {

	public void print(){
		System.out.println("bau");
	}
}
