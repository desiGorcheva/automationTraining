package com.pragmatic.lesson8.exceptions.coffee;

import com.pragmatic.lesson8.exceptions.coffee.exceptions.TooColdException;
import com.pragmatic.lesson8.exceptions.coffee.exceptions.TooHotException;

public class VirtualPerson {

    private static final int TOO_COLD = 65;
    private static final int TOO_HOT = 85;
    

    public void drinkCoffee(VirtualCoffeeCup cup) throws TooColdException, TooHotException  {
    	int currentTemperature = cup.getTemperature();
    	
    	if(currentTemperature < TOO_COLD) {
    		throw new TooColdException(currentTemperature);
    	}
    	
    	if(currentTemperature > TOO_HOT) {
    		throw new TooHotException(currentTemperature);
    	}
    		
    		
    }
}