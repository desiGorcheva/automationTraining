package com.pragmatic.lesson8.exceptions;

public class TooHotCoffeException extends Exception {

}
