package com.pragmatic.lesson8.exceptions.coffee;

public class CoffeeDemo {

	public static void main(String[] args) {
		VirtualPerson person = new VirtualPerson();
		VirtualCoffeeCup coffee = new VirtualCoffeeCup();
		coffee.setTemperature(70);

		VirtualCafe.serveCustomer(person, coffee);
		
		
	}

}
 