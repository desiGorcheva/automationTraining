package com.pragmatic.lesson8.exceptions.coffee.exceptions;

public class TemperatureException extends Exception {

	int temperature;
	
	public int getTemperature() {
		return temperature;
	}

	public void setTemperature(int temperature) {
		this.temperature = temperature;
	}

	public TemperatureException(int temperature) {
		this.temperature = temperature;
	}
	
	public TemperatureException() {
		super();
	}

	public TemperatureException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public TemperatureException(String message, Throwable cause) {
		super(message, cause);
	}

	public TemperatureException(String message) {
		super(message);
	}

	public TemperatureException(Throwable cause) {
		super(cause);
	}

	
}