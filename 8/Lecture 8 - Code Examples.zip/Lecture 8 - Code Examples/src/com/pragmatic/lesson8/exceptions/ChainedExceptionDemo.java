package com.pragmatic.lesson8.exceptions;

public class ChainedExceptionDemo {

	public static void main(String[] args) {
		String str = null;
		try {
			testMethod(str);
		} catch (RuntimeException e) {
			e.printStackTrace();
		}
		System.out.println("Prodalajvame natatyk");
	}
	
	private static void testMethod(String str) {
		try {
			if(str.equals("Ivan")) {
				System.out.println("Da tova e ivan");
			}
		} catch (NullPointerException e ) {
			throw new RuntimeException("Abe tuka edin se oplaka ot gadna parjola", e);
		}
	}
}
