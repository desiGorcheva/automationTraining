package com.pragmatic.lesson8.exceptions.coffee;

import com.pragmatic.lesson8.exceptions.coffee.exceptions.TooColdException;
import com.pragmatic.lesson8.exceptions.coffee.exceptions.TooHotException;

public class VirtualCafe {

    public static void serveCustomer(VirtualPerson cust, VirtualCoffeeCup cup)  {
    	
    	try {
			cust.drinkCoffee(cup);
			System.out.println("Oleee basi qkoto kafe");
		} catch (TooColdException e) {
			if(e.getTemperature() < 0) {
				System.out.println("sorry klient ama se zamrazi kafeto");
			} else {
				System.out.println("Abe nqma ti go dadem shtoto e studeno");
			}
			e.printStackTrace();
		} catch (TooHotException e) {
			if(e.getTemperature() > 200) {
				System.out.println("Basi kafeto s nad 200 gradusa");
			} else {
				System.out.println("Abe toplo e zaebi");
			}
			e.printStackTrace();
		}
    }
}