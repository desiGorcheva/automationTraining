

public class ForExample {
	public static void main(String[] args) {
		for (int i = 10; i >= 2; i = i - 1) {
			System.out.print(i + " ");
		}
	}
}
