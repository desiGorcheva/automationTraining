

public class Example {
	public static void main(String[] args) {
		int i = 100;
		while(i >= 1) {
			System.out.print(i + " ");
			//i--; 
			i = i - 1;
		}
	}
}
