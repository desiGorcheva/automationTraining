package gotowork.polymorphic;

public class Greek implements TaxPayer, Worker, Husband {

	@Override
	public void buyFlowers() {
		// TODO Auto-generated method stub

	}

	@Override
	public void goToWork() {
		System.out.println("Greek otiva na rabota");
	}

	@Override
	public void payTaxes() {
		// TODO Auto-generated method stub

	}

}
