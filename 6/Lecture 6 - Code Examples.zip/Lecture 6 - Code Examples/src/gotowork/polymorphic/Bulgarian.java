package gotowork.polymorphic;

public class Bulgarian implements Worker {

	@Override
	public void goToWork() {
		System.out.println("Bulgarian otiva na rabota");
	}

}
