package gotowork.polymorphic;

public interface Worker {
	void goToWork();

}
