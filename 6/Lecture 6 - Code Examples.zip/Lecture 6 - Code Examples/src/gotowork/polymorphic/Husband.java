package gotowork.polymorphic;

public interface Husband {
	void buyFlowers();
}
