package gotowork.polymorphic;

public interface TaxPayer {
	void payTaxes();

}
