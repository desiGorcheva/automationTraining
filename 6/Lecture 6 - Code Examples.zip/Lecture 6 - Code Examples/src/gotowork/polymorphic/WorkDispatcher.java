package gotowork.polymorphic;

public class WorkDispatcher {

	void makeThemWork(Worker worker) {
		worker.goToWork();
	}
}
