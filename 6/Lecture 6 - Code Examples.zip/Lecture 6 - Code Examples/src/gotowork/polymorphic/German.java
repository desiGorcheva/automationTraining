package gotowork.polymorphic;

public class German implements Worker {

	@Override
	public void goToWork() {
		System.out.println("German otiva na rabota");
	}

}
