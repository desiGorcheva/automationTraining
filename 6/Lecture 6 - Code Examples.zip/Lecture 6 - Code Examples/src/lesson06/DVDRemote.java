package lesson06;

public abstract class DVDRemote {
	abstract void play();
	abstract void stop();
	abstract void insertDisc();
	abstract void eject();
}
