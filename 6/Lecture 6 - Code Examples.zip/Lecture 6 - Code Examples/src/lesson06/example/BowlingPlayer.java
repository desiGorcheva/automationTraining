package lesson06.example;

public interface BowlingPlayer {
	void playBowling();
	void drinkBeer();
}
