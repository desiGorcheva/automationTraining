package lesson06.example;

public interface StickBringer {
	void bringStick();
}
