package lesson06.example;

public class Donkey implements StickBringer {

	@Override
	public void bringStick() {
		System.out.println("nosq prachka kato magare");
	}

}
