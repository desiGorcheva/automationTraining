package lesson06;

public interface IDVDController extends ITVContoller, IDVDRemoteController{
	
	void stopDVD();

}
