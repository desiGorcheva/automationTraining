package lesson06;

public interface IDVDRemoteController {
	void play();
	void stop();
	void insertDisc();
	void eject();
}
