package lesson06;

public interface ITVContoller {
	public void play();
	public void stop();
	public int goToChannel(int myDesiredChannel);
	public double goToChannel(double myDesiredChannel);
}
