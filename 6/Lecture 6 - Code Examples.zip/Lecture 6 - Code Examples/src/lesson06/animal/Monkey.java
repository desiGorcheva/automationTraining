package lesson06.animal;

public class Monkey extends Animal {

	@Override
	public void makeSomeNoise() {
		System.out.println("uuu uuu");
	}

	@Override
	public void play() {
		System.out.println("igraq si kat maimuna");
	}
	

	
}
