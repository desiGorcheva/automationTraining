package lesson06.animal;


public interface IZoo {
	
	Animal[] getAnimals();
	
	void addAnimal(Animal animalToAdd);

}
