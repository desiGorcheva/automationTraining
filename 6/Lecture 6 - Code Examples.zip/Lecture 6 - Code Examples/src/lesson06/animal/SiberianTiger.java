package lesson06.animal;

public class SiberianTiger extends Tiger {

	@Override
	public void makeSomeNoise() {
		System.out.println("uaaa kat sibirski");
	}

	@Override
	public void play() {
		System.out.println("igraq si kat siberiec");
	}

}
