package lesson06.animal;

public class BengalTiger extends Tiger {

	@Override
	public void makeSomeNoise() {
		System.out.println("uaaa kat bengal tiger");
	}

	@Override
	public void play() {
		System.out.println("igrivo bengalche");
	}

}
