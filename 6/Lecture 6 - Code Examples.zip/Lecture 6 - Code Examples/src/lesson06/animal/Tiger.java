package lesson06.animal;

public class Tiger extends Cat {

	@Override
	public void play() {
		// TODO Auto-generated method stub
		
	}


}
