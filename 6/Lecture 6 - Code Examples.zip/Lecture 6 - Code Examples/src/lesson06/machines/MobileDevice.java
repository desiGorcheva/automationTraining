package lesson06.machines;

public interface MobileDevice {
	
	void activateWiFi();

}
