package lesson06.machines;

public interface Machine {
	
	void turnOn();
	void turnOff();

}
