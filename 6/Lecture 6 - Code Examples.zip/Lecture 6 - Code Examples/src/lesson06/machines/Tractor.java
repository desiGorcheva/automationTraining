package lesson06.machines;

public class Tractor extends Functions {

	@Override
	public void turnOn() {
		System.out.println("Turning ON our TRACTOR TKZS");
	}

	@Override
	public void turnOff() {
		System.out.println("Turning OFF our TRACTOR TKZS");
		
	}

	@Override
	public void activateWiFi() {
		// TODO Auto-generated method stub
		
	}
	

}
