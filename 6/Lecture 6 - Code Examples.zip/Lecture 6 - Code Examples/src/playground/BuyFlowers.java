package playground;

public interface BuyFlowers extends Singer {
	void buyFlowers(int howMany);
}
