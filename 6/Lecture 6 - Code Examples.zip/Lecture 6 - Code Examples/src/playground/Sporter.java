package playground;

public interface Sporter {
	void run();
	void jump();
	void walk();
}
