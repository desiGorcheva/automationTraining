package playground;

public interface Singer {
	void sing();

}
