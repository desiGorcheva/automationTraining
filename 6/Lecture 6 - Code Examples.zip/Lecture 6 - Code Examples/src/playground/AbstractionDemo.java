package playground;

public class AbstractionDemo {

	public static void main(String[] args) {
		Person ivan = new Person();
		
		Sporter gosho = new Person();

		BuyFlowers tosho = new Person();
		
		BuyFlowers gosho2 = new Person();
		
	}

}
