package user.abstractions;

public interface User {
	void login();
	void logout();
	String getUserName();
	String getRegistrationDate();

}
