package users.implementations;

import user.abstractions.AbstractUser;

public class UserImpl extends AbstractUser {

	public UserImpl(String userName) {
		super(userName);
	}


}
