package driverExamples;

import static org.junit.Assert.*;

import org.junit.Test;

public class OurFirstTestClassTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
