package automation;

import org.junit.Test;

public class ClassThatWillNotRun {

	@Test
	public void notRunnedTest() {
		System.out.println("We will not see this.");
	}
	
}
