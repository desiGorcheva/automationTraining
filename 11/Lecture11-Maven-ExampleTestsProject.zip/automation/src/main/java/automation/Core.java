package automation;

/**
 * A class that is used for something inside our project
 * 
 * @author Santa Claus' Brother
 *
 */
public class Core {

	/**
	 * This is a core method that is used for something very special. :)
	 */
	public void coreMethod() {
		
	}
}
