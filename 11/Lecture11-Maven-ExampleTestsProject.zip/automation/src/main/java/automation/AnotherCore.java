package automation;

/**
 * This is a class that do nothing 
 * 
 * @author Santa Claus
 *
 */
public class AnotherCore {

	/**
	 * This method makes miracles
	 * 
	 * @param a you pass this parameter and it does nothing
	 */
	public void blablaMethod(int a) {
		
	}
}
